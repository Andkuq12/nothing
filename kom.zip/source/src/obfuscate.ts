import path from 'path';
import { fileURLToPath } from 'url';
import tmp from 'tmp';
import { spawn } from 'child_process';
import logger from './logger.ts';

// Dapatkan __dirname dalam konteks ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Obfuscate a Lua file using Prometheus Obfuscator
 * @param filename the path to the Lua file
 * @param preset the preset mode to use for obfuscation
 * @returns a Promise that resolves with the obfuscated file result
 */
export default function obfuscate(filename: string, preset: string): Promise<tmp.FileResult> {
    return new Promise((resolve, reject) => {
        // Buat file sementara untuk output
        const outFile = tmp.fileSync();

        // Bangun path absolut ke cli.lua
        const cliLuaPath = path.join(__dirname, '../lua/cli.lua');

        // Spawn process dengan menggunakan path yang benar
        const child = spawn('lua', [cliLuaPath, '--LuaU', '--preset', preset, filename, '--out', outFile.name]);

        child.stderr.on('data', (data) => {
            logger.error(data.toString());
            reject(data.toString());
        });
        child.on('close', () => {
            resolve(outFile);
        });
    });
}