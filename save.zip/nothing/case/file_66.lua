TextSB = " `2SELL SCIENCE STATION `92EACH `bAT `cVFDS ."
JumlahSB = 10000

    local count = 0
    for i = 1, JumlahSB do
        SendPacket(2, "action|input\ntext|/sb " .. TextSB)
        count = count + 1
        Sleep(1900)
        SendPacket(2, "action|input\ntext|`5Super BroadCast (megaphone) : `8[`b " .. count .. " / " .. JumlahSB .. " `8] ")
        Sleep(100000)
    end