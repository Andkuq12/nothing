module.exports = {
  "botToken": "7854409119:AAFIAUYnTrW-gfQ1FqsibcAf1St77XwlHlQ",
  "openaiApiKey": "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",
  "ownerId": 6283827994519,
  "adminIds": [
    111111111,
    222222222,
    
  ],
  "premiumIds": [
    333333333,
    444444444
  ]
};