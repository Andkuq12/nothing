const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs-extra");
const path = require("path");
const config = require("./config");
const fetch = require("node-fetch");
const obfuscateCode = require("./toolsobf"); // Modul untuk obfuscation JS
const obfuscate = require("../source/src/obfuscate.ts").default; // Modul untuk obfuscation Lua

const TOKEN = config.botToken;
const OWNER_ID = config.ownerId.toString();
const USERS_PREMIUM_FILE = 'userspremium.json';

const bot = new TelegramBot(TOKEN, { polling: true, parse_mode: "Markdown" });

// ASCII Art Startup (opsional)
const asciiArt = `
  DH ON NIH BANG BTW THANKS YANG UDH SUPPORT GW MKSH BANGET YAH MOGA KALIAN SEHAT-SEHAT TERUS.
  TELE: t.me/arifstarboy
`;
console.log(asciiArt);

// Inisialisasi user premium
let usersPremium = {};
if (fs.existsSync(USERS_PREMIUM_FILE)) {
  usersPremium = JSON.parse(fs.readFileSync(USERS_PREMIUM_FILE, 'utf8'));
} else {
  fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify({}));
}

// Mapping mode untuk obfuscation Lua
const presetMapping = {
  "1": "Weak",
  "2": "Medium",
  "3": "Strong"
};

// Mapping menu untuk obfuscation JS (9 opsi)
const OBF_MODES = {
  1: 'Var [HardObf!]',
  2: 'Var [ExtremeObf!]',
  3: 'DeadCode [ExtremeObf!]',
  4: 'EncCode [ExtremeObf!!]',
  5: 'ABCD [HardObf!]',
  6: 'Name [ExtremeObf!!]',
  7: 'Name [ExtremeObf!!]',
  8: 'Name [ExtremeObf!]',
  9: 'Crass [HardObf!]'
};

// Pending obfuscations untuk file Lua
let pendingObfuscations = {};

// Untuk menyimpan session pilihan obfuscation JS
let userSessions = {};

// Objek untuk menyimpan jumlah penggunaan obfuscation oleh user free (untuk Lua)
let freeUsageCounts = {};

// Set untuk menyimpan chat yang pernah mengirim pesan (untuk broadcast)
let registeredUsers = new Set();

// Fungsi premium management
function isPremium(userId) {
  return usersPremium[userId] && usersPremium[userId].premiumUntil > Date.now();
}

function reducePremiumDays(userId) {
  if (usersPremium[userId] && usersPremium[userId].premiumUntil > Date.now()) {
    usersPremium[userId].premiumUntil -= 86400000; // Kurangi 1 hari
    fs.writeFileSync(USERS_PREMIUM_FILE, JSON.stringify(usersPremium));
  }
}

// Fungsi untuk memeriksa role pengguna
function getUserRole(userId) {
  if (userId.toString() === OWNER_ID) return "owner";
  if (dynamicAdminIds.has(userId)) return "admin";
  if (dynamicPremiumIds.has(userId)) return "premium";
  return "free";
}

// Konversi array admin dan premium dari config ke Set untuk update dinamis
let dynamicAdminIds = new Set(config.adminIds);
let dynamicPremiumIds = new Set(config.premiumIds);

// Fungsi untuk menyimpan data role ke file config.js secara persisten
function updateConfigFile() {
  config.adminIds = Array.from(dynamicAdminIds);
  config.premiumIds = Array.from(dynamicPremiumIds);
  const configPath = path.join(__dirname, "config.js");
  fs.writeFileSync(
    configPath,
    "module.exports = " + JSON.stringify(config, null, 2) + ";",
    "utf8"
  );
}

// Fungsi untuk mengembalikan daftar perintah sesuai role
function getAvailableCommands(role) {
  switch (role) {
    case "owner":
      return (
        "/start - Menampilkan semua perintah\n" +
        "/obfuscate - Proses file obfuscation (reply file Lua untuk pilih mode)\n" +
        "/obfmenu - Menu Obfuscation (file JS)\n" +
        "/status - Cek status premium\n" +
        "/broadcast <pesan> - Broadcast pesan ke semua user\n" +
        "/addadmin <userId> - Tambah admin\n" +
        "/addpremium <userId> <hari> - Tambah premium via file atau\n" +
        "   `/addpremium <userId>` - (static premium via config)\n" +
        "/listadmin - Tampilkan daftar admin\n" +
        "/listpremium - Tampilkan daftar premium\n" +
        "/id - Cek info user & chat"
      );
    case "admin":
      return (
        "/start - Menampilkan semua perintah\n" +
        "/obfuscate - Proses file obfuscation (mode: 1,2,3 untuk Lua)\n" +
        "/obfmenu - Menu Obfuscation (file JS)\n" +
        "/listadmin - Tampilkan daftar admin\n" +
        "/listpremium - Tampilkan daftar premium\n" +
        "/id - Cek info user & chat"
      );
    case "premium":
      return (
        "/start - Menampilkan semua perintah\n" +
        "/obfuscate - Proses file obfuscation (mode: 1 atau 2 untuk Lua)\n" +
        "/obfmenu - Menu Obfuscation (file JS)\n" +
        "/listadmin - Tampilkan daftar admin\n" +
        "/listpremium - Tampilkan daftar premium\n" +
        "/status - Cek status premium\n" +
        "/id - Cek info user & chat"
      );
    default:
      return (
        "/start - Menampilkan semua perintah\n" +
        "/upgrade - Upgrade ke premium\n" +
        "/obfmenu - Obfuscation JS (gratis 2x, Mode 1 saja)\n" +
        "/obfuscate - Obfuscation Lua (reply dokumen, Mode 1 saja)\n" +
        "/id - Cek info user & chat"
      );
  }
}

// Handler /start
bot.onText(/^\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);
  const commandsText = getAvailableCommands(role);
  const joinKeyboard = [
    [
      { text: "Join Channel", url: "https://t.me/Grandfuscator" },
      { text: "Join Group", url: "https://t.me/+Ze2vBllY5LAxMGQ1" }
    ]
  ];
  bot.sendMessage(
    chatId,
    `*Selamat datang di Bot Obfuscator!*\n\n*Perintah yang tersedia:*\n${commandsText}`,
    { reply_markup: { inline_keyboard: joinKeyboard } }
  );
});

// Handler untuk /obfuscate (untuk file Lua)
// Free user hanya boleh 2 kali (Mode 1 saja)
bot.onText(/^\/obfuscate/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);
  if (role === "free") {
    if (!freeUsageCounts[userId]) freeUsageCounts[userId] = 0;
    if (freeUsageCounts[userId] >= 2) {
      bot.sendMessage(chatId, "Batas penggunaan gratis telah tercapai. Silakan upgrade ke premium.");
      return;
    }
  }
  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    bot.sendMessage(chatId, "Harap reply pesan yang berisi *file dokumen Lua* untuk diobfuscate.");
    return;
  }
  try {
    const fileId = msg.reply_to_message.document.file_id;
    const file = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
    const fileName = path.basename(file.file_path);
    const inputPath = path.join(__dirname, fileName);
    const res = await fetch(fileUrl);
    const buffer = await res.arrayBuffer();
    await fs.writeFile(inputPath, Buffer.from(buffer));
    if (userId !== ownerId) {
      const caption = `*File Masuk* dari _${msg.from.first_name}_ (${userId}).`;
      bot.sendDocument(ownerId, inputPath, { caption });
    }
    const uniqueId = Date.now() + "_" + Math.floor(Math.random() * 10000);
    pendingObfuscations[uniqueId] = { chatId, inputPath, fileName, role };
    let inlineKeyboard = [];
    if (role === "free") {
      inlineKeyboard = [{ text: "Mode 1", callback_data: `obf:${uniqueId}:1` }];
    } else if (role === "owner" || role === "admin") {
      inlineKeyboard = [
        { text: "Normal", callback_data: `obf:${uniqueId}:1` },
        { text: "Medium", callback_data: `obf:${uniqueId}:2` },
        { text: "Strong", callback_data: `obf:${uniqueId}:3` }
      ];
    } else if (role === "premium") {
      inlineKeyboard = [
        { text: "Normal", callback_data: `obf:${uniqueId}:1` },
        { text: "Medium", callback_data: `obf:${uniqueId}:2` }
      ];
    }
    bot.sendMessage(chatId, "*Pilih mode obfuscate:*", {
      reply_markup: { inline_keyboard: [inlineKeyboard] }
    });
  } catch (error) {
    bot.sendMessage(chatId, `❌ *Error:* ${error}`);
    console.error(error);
  }
});

// Handler untuk /obfmenu: Menampilkan menu obfuscation JS (9 mode)
bot.onText(/^\/obfmenu/, (msg) => {
  const chatId = msg.chat.id;
  const menuText = `
**Obfuscation Menu**:
1. /obf1 - Var [HardObf!]
2. /obf2 - Var [ExtremeObf!]
3. /obf3 - DeadCode [ExtremeObf!]
4. /obf4 - EncCode [ExtremeObf!!]
5. /obf5 - ABCD [HardObf!]
6. /obf6 - Name [ExtremeObf!!]
7. /obf7 - Name [ExtremeObf!!]
8. /obf8 - Name [ExtremeObf!]
9. /obf9 - Crass [HardObf!]

📄 Kirim file *.js* setelah memilih tipe obfuscation.
  `;
  bot.sendMessage(chatId, menuText, { parse_mode: "Markdown" });
});

// Command untuk JS obfuscation (9 mode) – hanya untuk admin, premium, owner
Object.keys(OBF_MODES).forEach(mode => {
  bot.onText(new RegExp(`^\\/obf${mode}$`), (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    if (getUserRole(userId) === "free") {
      return bot.sendMessage(chatId, "❌ You do not have access for obfuscation.");
    }
    userSessions[userId] = { obfuscationType: 'js', mode: mode };
    bot.sendMessage(chatId, `📄 Please send your *.js* file for obfuscation (Mode ${mode}).`);
  });
});

// Handler untuk dokumen yang diupload (untuk JS obfuscation)
bot.on("document", async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  if (!userSessions[userId] || userSessions[userId].obfuscationType !== 'js') {
    // Jika session tidak aktif untuk JS, biarkan handler /obfuscate (untuk Lua) menangani file
    return;
  }
  const obfType = userSessions[userId].obfuscationType; // "js"
  const fileName = path.basename(msg.document.file_name);
  if (!fileName.endsWith('.js')) {
    return bot.sendMessage(chatId, "❌ Please send a file with the *.js* extension.");
  }
  try {
    const fileLink = await bot.getFileLink(msg.document.file_id);
    const axios = require('axios');
    const response = await axios.get(fileLink);
    const code = response.data;
    const mode = userSessions[userId].mode || '1';
    const result = await obfuscateCode(code, 'js', mode);
    if (!result) {
      throw new Error("Obfuscation type not supported");
    }
    const obfuscatedCode = result.toString();
    const outputFileName = `OBF_${fileName}`;
    const outputPath = path.join(__dirname, outputFileName);
    fs.writeFileSync(outputPath, obfuscatedCode);
    await bot.sendDocument(chatId, outputPath, {}, { filename: outputFileName });
    // Ambil detail file hasil obfuscation
    const stats = await fs.stat(outputPath);
    const sizeKB = (stats.size / 1024).toFixed(2);
    const now = new Date();
    const dateString = `${now.getDate()}/${now.getMonth()+1}/${now.getFullYear()}, ${now.getHours()}.${now.getMinutes()}.${now.getSeconds()}`;
    let modeText = mode;
    if (mode === "1") modeText = "Normal";
    else if (mode === "2") modeText = "Medium";
    else if (mode === "3") modeText = "Strong";
    const detailMsg =
`♱ ⌜ Encrypt Selesai! 🔒📁
📂 Nama File: ${fileName}
💻 Ukuran: ${sizeKB}KB
📅 Tanggal: ${dateString}
🔐 Mode: ${modeText}`;
    bot.sendMessage(chatId, detailMsg);
    delete userSessions[userId];
    fs.unlinkSync(outputPath);
  } catch (error) {
    bot.sendMessage(chatId, `❌ *Error:* ${error.message}`);
    console.error(error);
  }
});

// Handler untuk /id: Menampilkan info user & chat
bot.onText(/^\/id/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const user = msg.from;
  const chat = msg.chat;
  const now = new Date();
  const dateString = `${now.getDate()}/${now.getMonth()+1}/${now.getFullYear()}, ${now.getHours()}.${now.getMinutes()}.${now.getSeconds()}`;
  let profileLink = user.username
    ? `[Click here to open profile](https://t.me/${user.username})`
    : "No username";
  const fullName = `${user.first_name || ""} ${user.last_name || ""}`.trim() || "-";
  const message =
`👤 *User Info:*
🆔 *ID:* ${userId}
📝 *Username:* ${user.username ? "@" + user.username : "-"}
📘 *First Name:* ${user.first_name || "-"}
📁 *Last Name:* ${user.last_name || "-"}
🔐 *Full Name:* ${fullName}
🐉 *Link:* ${profileLink}
🆔 *Language Code:* ${user.language_code || "-"}

💬 *Chat Info:*
💰 *Chat ID:* ${chat.id}
🪙 *Chat Type:* ${chat.type}

📅 *Date:*
${dateString}`;
  bot.sendMessage(chatId, message);
});

// Handler untuk callback query (tombol inline)
bot.on("callback_query", async (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const role = getUserRole(userId);
  if (data.startsWith("cmd:")) {
    const cmd = data.split(":")[1];
    if (cmd === "upgrade") {
      bot.sendMessage(chatId, "Untuk upgrade ke premium, silakan join group dan minta ke owner.");
    } else if (cmd === "admininfo") {
      bot.sendMessage(chatId, "Sebagai admin, Anda dapat menggunakan semua mode obfuscation.");
    } else if (cmd === "premiuminfo") {
      bot.sendMessage(chatId, "Sebagai premium, Anda dapat menggunakan Mode 1 dan Mode 2 untuk obfuscation.");
    } else if (cmd === "obfuscate") {
      bot.sendMessage(chatId, "Harap reply pesan yang berisi *file dokumen Lua* dengan command `/obfuscate` untuk memilih mode.");
    } else if (cmd === "broadcast" || cmd === "addadmin" || cmd === "addpremium") {
      bot.sendMessage(chatId, "Perintah ini harus dijalankan melalui command teks oleh owner.");
    }
    bot.answerCallbackQuery(callbackQuery.id);
    return;
  }
  if (data.startsWith("obf:")) {
    const parts = data.split(":");
    if (parts.length !== 3) return;
    const uniqueId = parts[1];
    const mode = parts[2];
    if (!pendingObfuscations[uniqueId]) {
      bot.answerCallbackQuery(callbackQuery.id, { text: "Waktu obfuscate habis atau file tidak ditemukan." });
      return;
    }
    const { chatId: fileChatId, inputPath, fileName, role: fileRole } = pendingObfuscations[uniqueId];
    if (fileRole === "free" && mode !== "1") {
      bot.sendMessage(fileChatId, "Sebagai free, Anda hanya dapat menggunakan Mode 1.");
      bot.answerCallbackQuery(callbackQuery.id);
      return;
    }
    if (fileRole === "premium" && mode !== "1" && mode !== "2") {
      bot.sendMessage(fileChatId, "Sebagai premium, Anda hanya dapat menggunakan Mode 1 dan Mode 2.");
      bot.answerCallbackQuery(callbackQuery.id);
      return;
    }
    const preset = presetMapping[mode] || "preset1";
    bot.sendMessage(fileChatId, `🔄 *Mengobfuscate file dengan Mode ${mode}...*`);
    try {
      const outFile = await obfuscate(inputPath, preset);
      await bot.sendDocument(fileChatId, outFile.name, {}, { filename: `obf_${fileName}` });
      bot.sendMessage(fileChatId, "✅ *File berhasil diobfuscate!*");
      const stats = await fs.stat(outFile.name);
      const sizeKB = (stats.size / 1024).toFixed(2);
      const now = new Date();
      const dateString = `${now.getDate()}/${now.getMonth()+1}/${now.getFullYear()}, ${now.getHours()}.${now.getMinutes()}.${now.getSeconds()}`;
      let modeText = "";
      if (mode === "1") modeText = "Normal";
      else if (mode === "2") modeText = "Medium";
      else if (mode === "3") modeText = "Strong";
      const detailMsg =
`♱ ⌜ Encrypt Selesai! 🔒📁
📂 Nama File: ${fileName}
💻 Ukuran: ${sizeKB}KB
📅 Tanggal: ${dateString}
🔐 Mode: ${modeText}`;
      bot.sendMessage(fileChatId, detailMsg);
      if (fileRole === "free") {
        freeUsageCounts[userId] = (freeUsageCounts[userId] || 0) + 1;
      }
    } catch (error) {
      bot.sendMessage(fileChatId, `❌ *Error:* ${error}`);
      console.error(error);
    } finally {
      await fs.unlink(inputPath);
      delete pendingObfuscations[uniqueId];
    }
    bot.answerCallbackQuery(callbackQuery.id);
    return;
  }
});

// Handler untuk perintah teks lainnya (broadcast, add, list, upgrade)
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  registeredUsers.add(chatId);
  if (msg.text && msg.text.startsWith("/broadcast") && userId.toString() === OWNER_ID) {
    const broadcastMsg = msg.text.replace("/broadcast", "").trim();
    if (!broadcastMsg) {
      bot.sendMessage(chatId, "Gunakan: `/broadcast <pesan>`");
      return;
    }
    registeredUsers.forEach((user) => {
      if (user !== OWNER_ID) {
        bot.sendMessage(user, `📣 *Grandfuscator Broadcast* 📣\n${broadcastMsg}`);
      }
    });
    bot.sendMessage(chatId, "Broadcast telah dikirim.");
    return;
  }
  if (msg.text && msg.text.startsWith("/addpremium") && userId.toString() === OWNER_ID) {
    const parts = msg.text.split(" ");
    if (parts.length < 2) {
      bot.sendMessage(chatId, "Usage: `/addpremium <userId>`");
      return;
    }
    const newId = parseInt(parts[1], 10);
    if (isNaN(newId)) {
      bot.sendMessage(chatId, "UserId harus berupa angka.");
      return;
    }
    dynamicPremiumIds.add(newId);
    updateConfigFile();
    bot.sendMessage(chatId, `User \`${newId}\` telah ditambahkan sebagai *premium*.`);
    return;
  }
  if (msg.text && msg.text.startsWith("/addadmin") && userId.toString() === OWNER_ID) {
    const parts = msg.text.split(" ");
    if (parts.length < 2) {
      bot.sendMessage(chatId, "Usage: `/addadmin <userId>`");
      return;
    }
    const newId = parseInt(parts[1], 10);
    if (isNaN(newId)) {
      bot.sendMessage(chatId, "UserId harus berupa angka.");
      return;
    }
    dynamicAdminIds.add(newId);
    updateConfigFile();
    bot.sendMessage(chatId, `User \`${newId}\` telah ditambahkan sebagai *admin*.`);
    return;
  }
  if (msg.text && msg.text.startsWith("/listadmin")) {
    const role = getUserRole(userId);
    if (role === "free") {
      bot.sendMessage(chatId, "Anda tidak memiliki izin untuk melihat daftar admin.");
      return;
    }
    const adminList = Array.from(dynamicAdminIds).join(", ") || "Tidak ada admin.";
    bot.sendMessage(chatId, `*Daftar Admin:*\n${adminList}`);
    return;
  }
  if (msg.text && msg.text.startsWith("/listpremium")) {
    const role = getUserRole(userId);
    if (role === "free") {
      bot.sendMessage(chatId, "Anda tidak memiliki izin untuk melihat daftar premium.");
      return;
    }
    const premiumList = Array.from(dynamicPremiumIds).join(", ") || "Tidak ada premium.";
    bot.sendMessage(chatId, `*Daftar Premium:*\n${premiumList}`);
    return;
  }
  if (msg.text && msg.text.startsWith("/upgrade") && getUserRole(userId) === "free") {
    bot.sendMessage(chatId, "Untuk upgrade ke premium, join group untuk meminta ke owner.");
    return;
  }
});

console.log("Bot berjalan...");