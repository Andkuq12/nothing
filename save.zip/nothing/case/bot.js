// ES Modules version (bot.mjs atau bot.js jika type: module)

import TelegramBot from "node-telegram-bot-api";
import fs from "fs-extra";
import path from "path";
import config from "./config.js";
import fetch from "node-fetch";
import axios from "axios";
import obfuscateImport from "../source/src/obfuscateq.js";

const obfuscate = obfuscateImport.default || obfuscateImport;

const __dirname = path.dirname(new URL(import.meta.url).pathname);

// API Key untuk OpenAI dan Gemini AI
const GEMINI_API_KEY = 'AIzaSyCDiGpOgSjcsG916el0p_GMBa0RywpYnKM';

const TOKEN = process.env.TELEGRAM_BOT_TOKEN || config.botToken;
const bot = new TelegramBot(TOKEN, { polling: true, parse_mode: "HTML" });

const ownerId = config.ownerId;

let dynamicAdminIds = new Set(config.adminIds);
let dynamicPremiumIds = new Set(config.premiumIds);

let tempRoles = {};

function updateConfigFile() {
  config.adminIds = Array.from(dynamicAdminIds);
  config.premiumIds = Array.from(dynamicPremiumIds);
  const configPath = path.join(__dirname, "config.js");
  fs.writeFileSync(
    configPath,
    "export default " + JSON.stringify(config, null, 2),
    "utf8"
  );
}

// lanjutkan dengan kode lain seperti yang kamu tulis sebelumnya...

// Mapping mode ke preset (untuk obfuscate file Lua)
const presetMapping = {
  "1": "Weak",
  "2": "Medium",
  "3": "Strong"
};

// Set untuk menyimpan user yang pernah mengirim pesan (untuk broadcast)
let registeredUsers = new Set();

// Objek untuk menyimpan file yang menunggu obfuscation (untuk file Lua)
let pendingObfuscations = {};

// Fungsi untuk memeriksa role pengguna (berdasarkan config)
function getUserRole(userId) {
  if (userId === ownerId) return "owner";
  if (dynamicAdminIds.has(userId)) return "admin";
  if (dynamicPremiumIds.has(userId)) return "premium";
  return "free";
}

// Fungsi untuk meng-escape karakter HTML
function escapeHTML(str) {
  return str.replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Fungsi untuk mengembalikan daftar perintah dalam format code block
function getAvailableCommands(role) {
  let commands;
  switch (role) {
    case "owner":
      commands =
        "/start - Menampilkan semua perintah\n" +
        "/obfuscate - Obfuscate file Lua (reply file dokumen)\n" +
        "/broadcast <pesan> - Broadcast pesan ke semua user\n" +
        "/addadmin <userId> - Tambah admin\n" +
        "/addpremium <userId> - Tambah premium\n" +
        "/listadmin - Tampilkan daftar admin\n" +
        "/listpremium - Tampilkan daftar premium\n" +
        "/ChatAI <pertanyaan> - Tanyakan sesuatu ke AI\n" +
        "/id - Cek info user, chat, dan role";
      break;
    case "admin":
      commands =
        "/start - Menampilkan semua perintah\n" +
        "/obfuscate - Obfuscate file Lua (mode: 1,2,3)\n" +
        "/listadmin - Tampilkan daftar admin\n" +
        "/listpremium - Tampilkan daftar premium\n" +
        "/ChatAI <pertanyaan> - Tanyakan sesuatu ke AI\n" +
        "/id - Cek info user, chat, dan role";
      break;
    case "premium":
      commands =
        "/start - Menampilkan semua perintah\n" +
        "/obfuscate - Obfuscate file Lua (mode: 1 atau 2)\n" +
        "/listadmin - Tampilkan daftar admin\n" +
        "/listpremium - Tampilkan daftar premium\n" +
        "/status - Cek status premium\n" +
        "/ChatAI <pertanyaan> - Tanyakan sesuatu ke AI\n" +
        "/id - Cek info user, chat, dan role";
      break;
    default:
      commands =
        "/start - Menampilkan semua perintah\n" +
        "/upgrade - Upgrade ke premium\n" +
        "/obfuscate - *2 kali gratis* (Mode 1 saja)\n" +
        "/ChatAI <pertanyaan> - Tanyakan sesuatu ke AI\n" +
        "/id - Cek info user, chat, dan role";
  }
  return `${escapeHTML(commands)}`;
}

// Handler /start: Kirim video beserta caption (daftar perintah) dalam satu pesan
bot.onText(/^\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);
  const commandsText = getAvailableCommands(role);

  // Inline keyboard: hanya Join Channel dan Join Group
  const joinKeyboard = [
    [
      { text: "Join Channel", url: "https://t.me/Grandfuscator" },
      { text: "Join Group", url: "https://t.me/+Ze2vBllY5LAxMGQ1" }
    ]
  ];

  // Kirim video dengan caption berupa daftar perintah (dalam format code block)
  bot.sendVideo(chatId, "https://e.top4top.io/m_336714chf7.mp4", {
    caption: commandsText,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: joinKeyboard }
  });
});

// Handler /obfuscate: Untuk obfuscate file Lua
// Jika pengguna free, langsung proses dengan Mode 1 (maks 2 kali)
// Jika premium, tampilkan pilihan Mode 1 dan 2
// Jika admin/owner, tampilkan pilihan Mode 1, 2, dan 3
let freeUsageCounts = {};
bot.onText(/^\/obfuscate/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);

  if (role === "free") {
    if (!freeUsageCounts[userId]) freeUsageCounts[userId] = 0;
    if (freeUsageCounts[userId] >= 2) {
      bot.sendMessage(chatId, "Batas penggunaan gratis telah tercapai. Silakan upgrade ke premium.");
      return;
    }
  }

  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    bot.sendMessage(chatId, "Harap reply pesan yang berisi *file dokumen Lua* untuk diobfuscate.");
    return;
  }

  try {
    const fileId = msg.reply_to_message.document.file_id;
    const file = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
    const fileName = path.basename(file.file_path);
    const inputPath = path.join(__dirname, fileName);

    const res = await fetch(fileUrl);
    const buffer = await res.arrayBuffer();
    await fs.writeFile(inputPath, Buffer.from(buffer));

    if (userId !== ownerId) {
      const caption = `*File Masuk* dari _${msg.from.first_name}_ (${userId}).`;
      bot.sendDocument(ownerId, inputPath, { caption });
    }

    // Jika pengguna free, langsung proses dengan Mode 1
    if (role === "free") {
      const mode = "1";
      bot.sendMessage(chatId, `🔄 *Mengobfuscate file dengan Mode ${mode}...*`);
      const preset = presetMapping[mode] || "preset1";
      const outFile = await obfuscate(inputPath, preset);
      await bot.sendDocument(chatId, outFile.name, {}, { filename: `obf_${fileName}` });
      bot.sendMessage(chatId, "✅ *File berhasil diobfuscate!*");
      
      const stats = await fs.stat(outFile.name);
      const sizeKB = (stats.size / 1024).toFixed(2);
      const nowDate = new Date();
      const dateString = `${nowDate.getDate()}/${nowDate.getMonth() + 1}/${nowDate.getFullYear()}, ${nowDate.getHours()}.${nowDate.getMinutes()}.${nowDate.getSeconds()}`;
      const detailMsg = `
♱ ⌜ Encrypt Selesai! 🔒📁
📂 Nama File: ${fileName}
💻 Ukuran: ${sizeKB}KB
📅 Tanggal: ${dateString}
🔐 Mode: Normal`;
      bot.sendMessage(chatId, detailMsg);
      freeUsageCounts[userId] = (freeUsageCounts[userId] || 0) + 1;
    } else {
      // Untuk premium, admin, dan owner: tampilkan inline keyboard untuk memilih mode
      const uniqueId = Date.now() + "_" + Math.floor(Math.random() * 10000);
      pendingObfuscations[uniqueId] = { chatId, inputPath, fileName, role };
      let inlineKeyboard = [];
      if (role === "premium") {
        inlineKeyboard = [
          { text: "Normal", callback_data: `obf:${uniqueId}:1` },
          { text: "Medium", callback_data: `obf:${uniqueId}:2` }
        ];
      } else if (role === "admin" || role === "owner") {
        inlineKeyboard = [
          { text: "Normal", callback_data: `obf:${uniqueId}:1` },
          { text: "Medium", callback_data: `obf:${uniqueId}:2` },
          { text: "Strong", callback_data: `obf:${uniqueId}:3` }
        ];
      }
      bot.sendMessage(chatId, "*Pilih mode obfuscate:*", {
        reply_markup: { inline_keyboard: [inlineKeyboard] }
      });
    }
  } catch (error) {
    bot.sendMessage(chatId, `❌ *Error:* ${error}`);
    console.error(error);
  }
});

// Handler untuk callback query (untuk pilihan mode obfuscate)
bot.on("callback_query", async (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const role = getUserRole(userId);

  if (data.startsWith("obf:")) {
    const parts = data.split(":");
    if (parts.length !== 3) return;
    const uniqueId = parts[1];
    const mode = parts[2];
    if (!pendingObfuscations[uniqueId]) {
      bot.answerCallbackQuery(callbackQuery.id, { text: "Waktu obfuscate habis atau file tidak ditemukan." });
      return;
    }
    const { chatId: fileChatId, inputPath, fileName, role: fileRole } = pendingObfuscations[uniqueId];
    // Validasi untuk premium: hanya Mode 1 atau 2; untuk admin/owner: Mode 1-3
    if (fileRole === "premium" && mode !== "1" && mode !== "2") {
      bot.sendMessage(fileChatId, "Sebagai premium, Anda hanya dapat menggunakan Mode 1 dan Mode 2.");
      bot.answerCallbackQuery(callbackQuery.id);
      return;
    }
    if (fileRole === "free" && mode !== "1") {
      bot.sendMessage(fileChatId, "Sebagai free, Anda hanya dapat menggunakan Mode 1.");
      bot.answerCallbackQuery(callbackQuery.id);
      return;
    }
    const preset = presetMapping[mode] || "preset1";
    bot.sendMessage(fileChatId, `🔄 *Mengobfuscate file dengan Mode ${mode}...*`);
    try {
      const outFile = await obfuscate(inputPath, preset);
      await bot.sendDocument(fileChatId, outFile.name, {}, { filename: `obf_${fileName}` });
      bot.sendMessage(fileChatId, "✅ *File berhasil diobfuscate!*");

      const stats = await fs.stat(outFile.name);
      const sizeKB = (stats.size / 1024).toFixed(2);
      const now = new Date();
      const dateString = `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}, ${now.getHours()}.${now.getMinutes()}.${now.getSeconds()}`;
      let modeText = "";
      if (mode === "1") modeText = "Normal";
      else if (mode === "2") modeText = "Medium";
      else if (mode === "3") modeText = "Strong";
      
      const detailMsg = `
♱ ⌜ Encrypt Selesai! 🔒📁
📂 Nama File: ${fileName}
💻 Ukuran: ${sizeKB}KB
📅 Tanggal: ${dateString}
🔐 Mode: ${modeText}`;
      bot.sendMessage(fileChatId, detailMsg);
      
      // Jika user free, increment penggunaan (meskipun tidak mungkin terjadi karena free tidak masuk ke callback)
      if (fileRole === "free") {
        freeUsageCounts[userId] = (freeUsageCounts[userId] || 0) + 1;
      }
    } catch (error) {
      bot.sendMessage(fileChatId, `❌ *Error:* ${error}`);
      console.error(error);
    } finally {
      await fs.unlink(inputPath);
      delete pendingObfuscations[uniqueId];
    }
    bot.answerCallbackQuery(callbackQuery.id);
    return;
  }
});

// Handler untuk /id: Menampilkan info user, chat, dan role
bot.onText(/^\/id/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const user = msg.from;
  const chat = msg.chat;
  const role = getUserRole(userId);
  const now = new Date();
  const dateString = `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}, ${now.getHours()}.${now.getMinutes()}.${now.getSeconds()}`;
  let profileLink = user.username
    ? `[Click here to open profile](https://t.me/${user.username})`
    : "No username";
  const fullName = `${user.first_name || ""} ${user.last_name || ""}`.trim() || "-";
  const infoText = 
`👤 User Info:
🆔 ID: ${userId}
📝 Username: ${user.username ? "@" + user.username : "-"}
📘 First Name: ${user.first_name || "-"}
📁 Last Name: ${user.last_name || "-"}
🔐 Full Name: ${fullName}
🐉 Link: ${profileLink}
🆔 Language Code: ${user.language_code || "-"}

💬 Chat Info:
💰 Chat ID: ${chat.id}
🪙 Chat Type: ${chat.type}

📌 Role: ${role.toUpperCase()}

📅 Date: ${dateString}`;

  // Kirim info dalam tag <pre> agar tampil seperti kotak kode
  bot.sendMessage(chatId, `<pre>${escapeHTML(infoText)}</pre>`, { parse_mode: "HTML" });
});

// Handler untuk perintah teks lainnya (broadcast, add, list, upgrade)
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  registeredUsers.add(chatId);
  
  if (msg.text && msg.text.startsWith("/broadcast") && userId.toString() === ownerId.toString()) {
  const broadcastMsg = msg.text.replace("/broadcast", "").trim();
  if (!broadcastMsg) {
    bot.sendMessage(chatId, "Gunakan: `/broadcast <pesan>`");
    return;
  }
  
  // Array untuk menyimpan promise pengiriman pesan
  const sendPromises = [];
  
  registeredUsers.forEach((user) => {
    // Lewati owner
    if (user.toString() !== ownerId.toString()) {
      // Tambahkan promise dengan error handling individual
      const promise = bot.sendMessage(user, `📣 Grandfuscator Broadcast*📣\n${broadcastMsg}`)
        .catch((err) => {
          console.error(`Broadcast ke ${user} gagal:`, err.message);
          // Bisa juga menyimpan daftar user yang gagal dikirim agar bisa dicoba lagi nanti
        });
      sendPromises.push(promise);
    }
  });
  
  // Tunggu semua pesan selesai diproses (baik sukses maupun error)
  Promise.allSettled(sendPromises).then((results) => {
    const failed = results.filter(result => result.status === "rejected");
    bot.sendMessage(chatId, `Broadcast telah dikirim. (Gagal ke ${failed.length} pengguna)`);
  });
  
  return;
}
  
  if (msg.text && msg.text.startsWith("/addpremium") && userId.toString() === ownerId.toString()) {
    const parts = msg.text.split(" ");
    if (parts.length < 2) {
      bot.sendMessage(chatId, "Usage: `/addpremium <userId>`");
      return;
    }
    const newId = parseInt(parts[1], 10);
    if (isNaN(newId)) {
      bot.sendMessage(chatId, "UserId harus berupa angka.");
      return;
    }
    dynamicPremiumIds.add(newId);
    updateConfigFile();
    bot.sendMessage(chatId, `User \`${newId}\` telah ditambahkan sebagai *premium*.`);
    return;
  }
  
  if (msg.text && msg.text.startsWith("/addadmin") && userId.toString() === ownerId.toString()) {
    const parts = msg.text.split(" ");
    if (parts.length < 2) {
      bot.sendMessage(chatId, "Usage: `/addadmin <userId>`");
      return;
    }
    const newId = parseInt(parts[1], 10);
    if (isNaN(newId)) {
      bot.sendMessage(chatId, "UserId harus berupa angka.");
      return;
    }
    dynamicAdminIds.add(newId);
    updateConfigFile();
    bot.sendMessage(chatId, `User \`${newId}\` telah ditambahkan sebagai *admin*.`);
    return;
  }
  
  if (msg.text && msg.text.startsWith("/listadmin")) {
    const role = getUserRole(userId);
    if (role === "free") {
      const accadm = `Anda tidak memiliki izin untuk melihat daftar admin.`;
      bot.sendMessage(chatId, `<pre>${escapeHTML(accadm)}</pre>`, { parse_mode: "HTML" });
      return;
    }
    const adminList = Array.from(dynamicAdminIds).join(", ") || "Tidak ada admin.";
    const listadm = `Daftar Admin:\n${adminList}`;
    bot.sendMessage(chatId, `<pre>${escapeHTML(listadm)}</pre>`, { parse_mode: "HTML" });
    return;
  }
  
  if (msg.text && msg.text.startsWith("/listpremium")) {
    const role = getUserRole(userId);
    if (role === "free") {
      bot.sendMessage(chatId, "Anda tidak memiliki izin untuk melihat daftar premium.");
      return;
    }
    const premiumList = Array.from(dynamicPremiumIds).join(", ") || "Tidak ada premium.";
    const listprem = `Daftar Premium:\n${premiumList}`;
    bot.sendMessage(chatId, `<pre>${escapeHTML(listprem)}</pre>`, { parse_mode: "HTML" });
    return;
  }
  
  if (msg.text && msg.text.startsWith("/upgrade") && getUserRole(userId) === "free") {
    bot.sendMessage(chatId, "Untuk upgrade ke premium, join group untuk meminta ke owner.");
    return;
  }
  
  
  
// Handler untuk command Gemini AI: /aiGemini
if (msg.text && msg.text.startsWith("/ChatAI")) {
  const question = msg.text.replace("/ChatAI", "").trim();
  if (!question) {
    bot.sendMessage(chatId, "Silakan masukkan pertanyaan setelah perintah /ChatAI.\nContoh: /ChatAI Apa itu JavaScript?");
    return;
  }

  bot.sendMessage(chatId, " *Memproses pertanyaan dengan AI...*", { parse_mode: "Markdown" });

  try {
    const response = await axios.post(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent", // Menggunakan model gemini-1.5-flash
      {
        contents: [{ parts: [{ text: question }] }],
      },
      {
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": GEMINI_API_KEY,
        },
      }
    );
    const answer = response.data.candidates[0].content.parts[0].text.trim();
    bot.sendMessage(chatId, answer);
  } catch (error) {
    const errorMessage = error.response?.data?.error?.message || error.message;
    bot.sendMessage(chatId, `❌ Terjadi error saat memproses pertanyaan Gemini AI: ${errorMessage}`);
    console.error(error);
  }
  return;
}

});

console.log("Bot berjalan...");


