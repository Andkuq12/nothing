const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs-extra");
const path = require("path");
const config = require("./config");
const fetch = require("node-fetch");

// Import modul obfuscate. Pastikan modul TS telah dikompilasi ke JS atau gunakan ts-node.
const obfuscate = require("../source/src/obfuscate.ts").default;

const TOKEN = config.botToken;
const bot = new TelegramBot(TOKEN, { polling: true });

// Role configuration: ambil ID dari config
const ownerId = config.ownerId; // misal: 123456789

// Konversi array admin dan premium dari config ke Set untuk update dinamis
let dynamicAdminIds = new Set(config.adminIds);
let dynamicPremiumIds = new Set(config.premiumIds);

// Fungsi untuk menyimpan data role ke file config.js secara persisten
function updateConfigFile() {
  // Update properti config berdasarkan Set dinamis
  config.adminIds = Array.from(dynamicAdminIds);
  config.premiumIds = Array.from(dynamicPremiumIds);
  // Tentukan path config.js relatif ke folder ini
  const configPath = path.join(__dirname, "config.js");
  // Tulis ulang file config.js dengan format module.exports
  fs.writeFileSync(
    configPath,
    "module.exports = " + JSON.stringify(config, null, 2) + ";",
    "utf8"
  );
}

// Mapping mode ke preset (sesuaikan dengan preset yang disediakan obfuscator Anda)
const presetMapping = {
  "1": "Weak",
  "2": "Medium",
  "3": "Strong"
};

// Set untuk menyimpan user yang pernah mengirim pesan (untuk broadcast)
let registeredUsers = new Set();

// Objek untuk menyimpan file yang menunggu obfuscation
let pendingObfuscations = {};

// Fungsi untuk memeriksa role pengguna
function getUserRole(userId) {
  if (userId === ownerId) return "owner";
  if (dynamicAdminIds.has(userId)) return "admin";
  if (dynamicPremiumIds.has(userId)) return "premium";
  return "free";
}

// Fungsi untuk mengembalikan daftar perintah (all commands) sesuai role
function getAvailableCommands(role) {
  switch (role) {
    case "owner":
      return `/start - Menampilkan semua perintah
/obfuscate - Proses file obfuscation (pilih mode melalui tombol)
 /broadcast <pesan> - Broadcast pesan ke semua user
 /addadmin <userId> - Tambah admin
 /addpremium <userId> - Tambah premium
 /listadmin - Tampilkan daftar admin
 /listpremium - Tampilkan daftar premium`;
    case "admin":
      return `/start - Menampilkan semua perintah
/obfuscate - Proses file obfuscation (mode: 1,2,3)
/listadmin - Tampilkan daftar admin
/listpremium - Tampilkan daftar premium`;
    case "premium":
      return `/start - Menampilkan semua perintah
/obfuscate - Proses file obfuscation (mode: 1 atau 2)
/listadmin - Tampilkan daftar admin
/listpremium - Tampilkan daftar premium`;
    default:
      return `/start - Menampilkan semua perintah
/upgrade - Upgrade ke premium`;
  }
}

// Handler /start: Mengirim pesan daftar semua perintah sesuai role dan tombol join channel/group
bot.onText(/^\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);
  const commandsText = getAvailableCommands(role);

  // Inline keyboard untuk join channel dan group
  const joinKeyboard = [
    [
      { text: "Join Channel", url: "https://t.me/Grandfuscator" },
      { text: "Join Group", url: "https://t.me/+Ze2vBllY5LAxMGQ1" }
    ]
  ];

  bot.sendMessage(chatId, `Selamat datang di Bot Obfuscator.\n\nPerintah yang tersedia:\n${commandsText}`, {
    reply_markup: {
      inline_keyboard: joinKeyboard
    }
  });
});

// Handler untuk command /obfuscate (dijalankan saat reply pesan yang berisi dokumen Lua)
// Perintah ini mengirimkan inline keyboard untuk memilih mode obfuscate
bot.onText(/^\/obfuscate/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const role = getUserRole(userId);

  // Hanya premium, admin, atau owner yang dapat menggunakan perintah ini
  if (role === "free") {
    bot.sendMessage(chatId, "Fitur ini hanya tersedia untuk premium, admin, atau owner.");
    return;
  }

  // Pastikan pesan ini adalah reply terhadap pesan yang berisi dokumen
  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    bot.sendMessage(chatId, "Harap reply pesan yang berisi file dokumen Lua untuk diobfuscate.");
    return;
  }

  try {
    // Dapatkan informasi file dari pesan reply
    const fileId = msg.reply_to_message.document.file_id;
    const file = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
    const fileName = path.basename(file.file_path);
    const inputPath = path.join(__dirname, fileName);

    // Unduh file dari Telegram
    const res = await fetch(fileUrl);
    const buffer = await res.arrayBuffer();
    await fs.writeFile(inputPath, Buffer.from(buffer));

    // Jika pengirim bukan owner, kirim file input ke owner sebagai notifikasi
    if (userId !== ownerId) {
      const caption = `Input file dari ${msg.from.first_name} (${userId}).`;
      bot.sendDocument(ownerId, inputPath, { caption });
    }

    // Buat ID unik untuk mengidentifikasi file ini dan simpan datanya
    const uniqueId = Date.now() + "_" + Math.floor(Math.random() * 10000);
    pendingObfuscations[uniqueId] = { chatId, inputPath, fileName, role };

    // Buat inline keyboard untuk memilih mode sesuai role
    let inlineKeyboard = [];
    if (role === "owner") {
      inlineKeyboard = [
        { text: "Mode 1", callback_data: `obf:${uniqueId}:1` },
        { text: "Mode 2", callback_data: `obf:${uniqueId}:2` },
        { text: "Mode 3", callback_data: `obf:${uniqueId}:3` }
      ];
    } else if (role === "admin") {
      inlineKeyboard = [
        { text: "Mode 1", callback_data: `obf:${uniqueId}:1` },
        { text: "Mode 2", callback_data: `obf:${uniqueId}:2` },
        { text: "Mode 3", callback_data: `obf:${uniqueId}:3` }
      ];
    } else if (role === "premium") {
      inlineKeyboard = [
        { text: "Mode 1", callback_data: `obf:${uniqueId}:1` },
        { text: "Mode 2", callback_data: `obf:${uniqueId}:2` }
      ];
    }

    // Kirim inline keyboard untuk pemilihan mode
    bot.sendMessage(chatId, "Pilih mode obfuscate:", {
      reply_markup: {
        inline_keyboard: [inlineKeyboard]
      }
    });
  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error}`);
    console.error(error);
  }
});

// Handler untuk callback query (untuk tombol inline)
// Menangani dua jenis callback: "cmd:" (perintah dari /start) dan "obf:" (pemilihan mode obfuscate)
bot.on("callback_query", async (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const role = getUserRole(userId);

  // Jika callback untuk command (prefix "cmd:")
  if (data.startsWith("cmd:")) {
    const cmd = data.split(":")[1];
    if (cmd === "upgrade") {
      bot.sendMessage(chatId, "Untuk upgrade ke premium, join group untuk meminta ke owner.");
    } else if (cmd === "admininfo") {
      bot.sendMessage(chatId, "Sebagai admin, Anda dapat menggunakan semua Mode untuk obfuscation.");
    } else if (cmd === "premiuminfo") {
      bot.sendMessage(chatId, "Sebagai premium, Anda dapat menggunakan Mode 1 dan Mode 2 untuk obfuscation.");
    } else if (cmd === "obfuscate") {
      bot.sendMessage(chatId, "Harap reply pesan yang berisi file berjenis Lua dengan command /obfuscate untuk memilih mode.");
    } else if (cmd === "broadcast" || cmd === "addadmin" || cmd === "addpremium") {
      bot.sendMessage(chatId, "Perintah ini harus dijalankan melalui command teks oleh owner.");
    }
    bot.answerCallbackQuery(callbackQuery.id);
    return;
  }

  // Jika callback untuk obfuscation (prefix "obf:")
  if (data.startsWith("obf:")) {
    const parts = data.split(":");
    if (parts.length !== 3) return;
    const uniqueId = parts[1];
    const mode = parts[2];

    if (!pendingObfuscations[uniqueId]) {
      bot.answerCallbackQuery(callbackQuery.id, { text: "Waktu obfuscate habis atau file tidak ditemukan." });
      return;
    }

    const { chatId: fileChatId, inputPath, fileName, role: fileRole } = pendingObfuscations[uniqueId];

    // Validasi mode berdasarkan role
    if (fileRole === "admin" && mode !== "3") {
      bot.sendMessage(fileChatId, "Sebagai admin, Anda dapat menggunakan semua Mode.");
      bot.answerCallbackQuery(callbackQuery.id);
      return;
    }
    if (fileRole === "premium" && mode !== "1" && mode !== "2") {
      bot.sendMessage(fileChatId, "Sebagai premium, Anda hanya dapat menggunakan Mode 1 dan Mode 2.");
      bot.answerCallbackQuery(callbackQuery.id);
      return;
    }

    const preset = presetMapping[mode] || "preset1";
    bot.sendMessage(fileChatId, `🔄 Mengobfuscate file dengan Mode ${mode}...`);

    try {
      const outFile = await obfuscate(inputPath, preset);
      await bot.sendDocument(fileChatId, outFile.name, {}, { filename: `obf_${fileName}` });
      bot.sendMessage(fileChatId, "✅ File berhasil diobfuscate!");
    } catch (error) {
      bot.sendMessage(fileChatId, `❌ Error: ${error}`);
      console.error(error);
    } finally {
      // Hapus file input dan bersihkan data pending
      await fs.unlink(inputPath);
      delete pendingObfuscations[uniqueId];
    }

    bot.answerCallbackQuery(callbackQuery.id);
    return;
  }
});

// Handler untuk perintah teks selain /start dan /obfuscate,
// termasuk perintah owner untuk broadcast, penambahan role, dan perintah listing.
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  // Simpan chatId untuk broadcast
  registeredUsers.add(chatId);

  // Perintah broadcast: hanya owner yang dapat menggunakannya
  if (msg.text && msg.text.startsWith("/broadcast") && userId === ownerId) {
    const broadcastMsg = msg.text.replace("/broadcast", "").trim();
    if (!broadcastMsg) {
      bot.sendMessage(chatId, "Gunakan: /broadcast <pesan>");
      return;
    }
    registeredUsers.forEach((user) => {
      if (user !== ownerId) {
        bot.sendMessage(user, `📣📣Grandfuscator Broadcast📣📣\n ${broadcastMsg}`);
      }
    });
    bot.sendMessage(chatId, "Broadcast telah dikirim.");
    return;
  }
  
  // Perintah untuk menambahkan premium: /addpremium <userId>
  if (msg.text && msg.text.startsWith("/addpremium") && userId === ownerId) {
    const parts = msg.text.split(" ");
    if (parts.length < 2) {
      bot.sendMessage(chatId, "Usage: /addpremium <userId>");
      return;
    }
    const newId = parseInt(parts[1], 10);
    if (isNaN(newId)) {
      bot.sendMessage(chatId, "UserId harus berupa angka.");
      return;
    }
    dynamicPremiumIds.add(newId);
    updateConfigFile(); // Simpan perubahan ke config.js
    bot.sendMessage(chatId, `User ${newId} telah ditambahkan sebagai premium.`);
    return;
  }

  // Perintah untuk menambahkan admin: /addadmin <userId>
  if (msg.text && msg.text.startsWith("/addadmin") && userId === ownerId) {
    const parts = msg.text.split(" ");
    if (parts.length < 2) {
      bot.sendMessage(chatId, "Usage: /addadmin <userId>");
      return;
    }
    const newId = parseInt(parts[1], 10);
    if (isNaN(newId)) {
      bot.sendMessage(chatId, "UserId harus berupa angka.");
      return;
    }
    dynamicAdminIds.add(newId);
    updateConfigFile(); // Simpan perubahan ke config.js
    bot.sendMessage(chatId, `User ${newId} telah ditambahkan sebagai admin.`);
    return;
  }
  
  // Perintah untuk menampilkan daftar admin
  if (msg.text && msg.text.startsWith("/listadmin")) {
    // Hanya user yang tidak free yang dapat melihat daftar admin
    const role = getUserRole(userId);
    if (role === "free") {
      bot.sendMessage(chatId, "Anda tidak memiliki izin untuk melihat daftar admin.");
      return;
    }
    const adminList = Array.from(dynamicAdminIds).join(", ") || "Tidak ada admin.";
    bot.sendMessage(chatId, `Daftar Admin:\n${adminList}`);
    return;
  }
  
  // Perintah untuk menampilkan daftar premium
  if (msg.text && msg.text.startsWith("/listpremium")) {
    // Hanya user yang tidak free yang dapat melihat daftar premium
    const role = getUserRole(userId);
    if (role === "free") {
      bot.sendMessage(chatId, "Anda tidak memiliki izin untuk melihat daftar premium.");
      return;
    }
    const premiumList = Array.from(dynamicPremiumIds).join(", ") || "Tidak ada premium.";
    bot.sendMessage(chatId, `Daftar Premium:\n${premiumList}`);
    return;
  }
  
  // Perintah upgrade untuk free user
  if (msg.text && msg.text.startsWith("/upgrade") && getUserRole(userId) === "free") {
    bot.sendMessage(chatId, "Untuk upgrade ke premium, join group untuk meminta ke owner.");
    return;
  }
});

console.log("Bot berjalan...");