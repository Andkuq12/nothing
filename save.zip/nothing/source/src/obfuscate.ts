const path = require('path');
const tmp = require('tmp');
const { spawn } = require('child_process');

/**
 * Obfuscate a Lua file using Prometheus Obfuscator
 * @param {string} filename - the path to the Lua file
 * @param {string} preset - the preset mode to use for obfuscation
 * @returns {Promise<tmp.FileResult>}
 */
function obfuscate(filename, preset) {
    return new Promise((resolve, reject) => {
        // Buat file sementara untuk output
        const outFile = tmp.fileSync();

        // Path ke cli.lua relatif terhadap file ini
        const cliLuaPath = path.join(__dirname, '../lua/cli.lua');

        // Jalankan proses obfuscation
        const child = spawn('lua', [cliLuaPath, '--LuaU', '--preset', preset, filename, '--out', outFile.name]);

        child.stderr.on('data', (data) => {
            reject(data.toString());
        });

        child.on('close', () => {
            resolve(outFile);
        });
    });
}

module.exports = obfuscate;
