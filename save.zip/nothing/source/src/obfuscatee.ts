const path = require('path');
const tmp = require('tmp');
const { spawn } = require('child_process');

function obfuscate(filename, preset) {
    return new Promise((resolve, reject) => {
        const outFile = tmp.fileSync();
        const cliLuaPath = path.join(__dirname, '../lua/cli.lua');

        const child = spawn('lua', [cliLuaPath, '--LuaU', '--preset', preset, filename, '--out', outFile.name]);

        child.stderr.on('data', (data) => {
            reject(data.toString());
        });

        child.on('close', () => {
            resolve(outFile);
        });
    });
}

module.exports = obfuscate;
